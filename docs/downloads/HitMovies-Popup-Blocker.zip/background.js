'use strict';
const SITE_ORIGINS = new Set(['https://hitmovies-emerald-cinema.awaremelon2.chatgpt.site','https://hitmovies-emerald-cinema.matajcicmoris.chatgpt.site']);
const closingTabs = new Set();
const blockedCounts = new Map();
const isHitMovies = value => { try { return SITE_ORIGINS.has(new URL(value).origin); } catch { return false; } };

async function isProtected(id) {
  if (!Number.isInteger(id) || id < 0) return false;
  try {
    const tab = await chrome.tabs.get(id);
    return isHitMovies(tab.url) || isHitMovies(tab.pendingUrl);
  } catch { /* A tab may close before this event is processed. */ }
  return false;
}

async function returnToMovie(sourceId) {
  try {
    const source = await chrome.tabs.get(sourceId);
    if (!isHitMovies(source.url) && !isHitMovies(source.pendingUrl)) return;
    await chrome.tabs.update(sourceId, {active:true});
    if (Number.isInteger(source.windowId)) await chrome.windows.update(source.windowId, {focused:true});
  } catch { /* The viewer may have closed or navigated away from the movie. */ }
}

async function closeChild(sourceId, targetId) {
  if (!Number.isInteger(targetId) || targetId < 0 || targetId === sourceId || closingTabs.has(targetId)) return;
  if (!await isProtected(sourceId) || closingTabs.has(targetId)) return;
  closingTabs.add(targetId);
  try {
    const popup = await chrome.tabs.get(targetId);
    await chrome.tabs.remove(targetId);
    // Closing a popup window can otherwise leave an older Extensions window in front.
    // Restore only the originating movie when the popup was the selected tab.
    if (popup.active) await returnToMovie(sourceId);
    const count = (blockedCounts.get(sourceId) || 0) + 1;
    blockedCounts.set(sourceId, count);
    await Promise.allSettled([
      chrome.action.setBadgeText({tabId: sourceId, text: count > 99 ? '99+' : String(count)}),
      chrome.action.setBadgeBackgroundColor({tabId: sourceId, color: '#239658'}),
      chrome.action.setTitle({tabId: sourceId, title: 'HitMovies: '+count+' popup tab'+(count === 1 ? '' : 's')+' blocked'})
    ]);
  } catch { /* The browser or another blocker may already have closed this popup. */ }
  finally { closingTabs.delete(targetId); }
}

// This also covers window.open(..., 'noopener') and cross-origin player frames.
chrome.webNavigation.onCreatedNavigationTarget.addListener(details => {
  void closeChild(details.sourceTabId, details.tabId);
});
chrome.tabs.onCreated.addListener(tab => {
  if (Number.isInteger(tab.openerTabId)) void closeChild(tab.openerTabId, tab.id);
});
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  const url = change.url || tab.url;
  if (url && !isHitMovies(url) || change.status === 'loading' && !isHitMovies(tab.url) && !isHitMovies(tab.pendingUrl)) {
    blockedCounts.delete(id);
    void chrome.action.setBadgeText({tabId:id,text:''}).catch(() => {});
  }
});
chrome.tabs.onRemoved.addListener(id => {
  blockedCounts.delete(id);
  closingTabs.delete(id);
});

