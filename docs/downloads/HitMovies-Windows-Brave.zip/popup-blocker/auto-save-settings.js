'use strict';
const tabId=Number(new URL(location.href).searchParams.get('tab'));let needed=null;
const $=id=>document.getElementById(id);
async function refresh(){
  const state=await chrome.runtime.sendMessage({type:'hitmovies-setup-status',tabId});
  needed=state?.needed||null;$('allow').hidden=!needed;$('origin').textContent=needed||'';
  $('heading').textContent=needed?'Allow access to this movie player':state?.error?'Open your movie first':state?.ready?'Player access is enabled':'Waiting for the video player';
  $('message').textContent=state?.error|| (needed?'This lets the companion read and restore the video position. Your browser will ask you to confirm access to this host.':state?.ready?'Your actual playback position will save automatically while you watch.':'Press play in HitMovies. Automatic saving starts when the video becomes available.');
  $('ready').hidden=!state?.ready;
  if(!needed&&!state?.error)await chrome.runtime.sendMessage({type:'hitmovies-setup-refresh',tabId});
}
$('allow').addEventListener('click',()=>{
  if(!needed)return;
  // The request is made directly from this explicit user click, for one exact origin.
  chrome.permissions.request({origins:[needed+'/*']}).then(granted=>{if(granted)refresh();else $('message').textContent='Access was not enabled. You can continue using a manual bookmark or allow this player later.';});
});
$('refresh').addEventListener('click',refresh);refresh();setInterval(refresh,2000);
