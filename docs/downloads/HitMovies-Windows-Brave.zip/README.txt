HitMovies for Windows — Brave launcher

Double-click HitMovies.exe to open the live HitMovies site in a Brave app window.
Brave must be installed. Internet access is required.
The app starts maximized, keeping normal window controls and the taskbar.
Use the movie player Fullscreen button for video-only fullscreen; press Esc to leave it.
Create a HitMovies account with a username and password, or log in to your existing account.
Use the same account on other devices to sync your profiles, watchlist and Continue Watching.
No ChatGPT account is required. Automatic time saving works with the included HitMovies Companion.
Load or reload the popup-blocker folder in Brave Extensions (Developer mode > Load unpacked).
Open a movie, click Enable automatic saving, and allow only the displayed player hosts.
This one-time setup lets the companion read and restore the actual video position.
It also blocks additional player tabs. New player hosts may need permission later.

Optional: double-click Install-HitMovies.cmd to create desktop and Start menu shortcuts.
No administrator access is needed. This only installs the small launcher.

To access Brave's Shields controls in a normal browser window, run:
  HitMovies.exe --browser
The optional install also adds a 'HitMovies in Brave Browser' Start menu shortcut.

The launcher preserves your existing Brave profile and settings.
It never disables Shields and contains no API keys or account credentials.
Brave Shields blocks many ads and trackers; complete ad-free playback is not guaranteed.

Remove a portable copy by deleting its files.
Remove an installed copy by deleting its desktop shortcut, its Start menu HitMovies folder,
and %LOCALAPPDATA%\Programs\HitMovies. Brave and its data remain in place.

Website: https://hitmovies-emerald-cinema.matajcicmoris.chatgpt.site/
