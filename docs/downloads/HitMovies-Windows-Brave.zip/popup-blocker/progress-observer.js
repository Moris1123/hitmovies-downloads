(() => {
  'use strict';
  if(window.__hitmoviesProgressObserver)return;
  window.__hitmoviesProgressObserver=true;
  const sites=new Set(['https://hitmovies-emerald-cinema.matajcicmoris.chatgpt.site','https://hitmovies-emerald-cinema.awaremelon2.chatgpt.site']);
  const topFrame=window===window.top,owner=topFrame&&sites.has(location.origin);
  const native=!!window.webkit?.messageHandlers?.hitmoviesProgress;
  const extension=typeof chrome!=='undefined'&&!!chrome.runtime?.id;
  if(!native&&!extension)return;
  let context=null,lastContext='',generation=0;
  const watched=new WeakMap();
  function send(message){try{if(native)window.webkit.messageHandlers.hitmoviesProgress.postMessage(message);else chrome.runtime.sendMessage({type:'hitmovies-observer',...message}).catch(()=>{});}catch{}}
  function children(){
    if(owner)return [...document.querySelectorAll('iframe.movie-frame')];
    if(location.origin==='https://api.codespecters.com')return [...document.querySelectorAll('iframe#stream-frame')];
    const frames=[...document.querySelectorAll('iframe')].filter(frame=>{const rect=frame.getBoundingClientRect();return rect.width*rect.height>Math.max(2000,innerWidth*innerHeight*.4);});
    return frames.sort((a,b)=>{const x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return y.width*y.height-x.width*x.height;}).slice(0,1);
  }
  function forward(){if(!context)return;for(const frame of children()){try{frame.contentWindow.postMessage({type:'HITMOVIES_FRAME_CONTEXT',...context},'*');}catch{}}}
  function accept(next){
    if(!next||typeof next.session!=='string'||!/^[-a-z0-9]{20,80}$/i.test(next.session))return;
    if(context?.session!==next.session)generation++;
    context={session:next.session,resume:Number.isFinite(next.resume)&&next.resume>=0?next.resume:0};
    forward();scan();
  }
  window.addEventListener('message',event=>{
    if(!topFrame&&event.source===parent&&event.data?.type==='HITMOVIES_FRAME_CONTEXT')accept(event.data);
    if(owner&&event.source===window&&event.origin===location.origin&&event.data?.type==='HITMOVIES_AUTO_SETUP'&&context?.session===event.data.session&&extension)send({kind:'setup',session:context.session});
  });
  if(owner&&extension)chrome.runtime.onMessage.addListener(message=>{
    if(!context||message.session!==context.session)return;
    if(message.type==='hitmovies-progress-delivery')window.postMessage({type:'HITMOVIES_AUTO_PROGRESS',...message.data},location.origin);
    if(message.type==='hitmovies-capability')window.postMessage({type:'HITMOVIES_AUTO_CAPABILITY',session:context.session,available:message.available,needsAccess:message.needsAccess},location.origin);
  });
  function observe(video){
    if(watched.has(video))return;
    const state={source:crypto.randomUUID(),generation:-1,lastTime:-1,lastReport:0};watched.set(video,state);
    function report(reason='tick'){
      if(!context)return;
      const duration=video.duration,time=video.currentTime;
      if(!Number.isFinite(duration)||duration<30||duration>604800||!Number.isFinite(time)||time<0||time>duration+1)return;
      const rect=video.getBoundingClientRect(),area=Math.max(0,rect.width*rect.height),visible=area>=2000&&getComputedStyle(video).visibility!=='hidden'&&getComputedStyle(video).display!=='none';
      if(!visible&&state.lastReport===0)return;
      if(state.generation!==generation){
        state.generation=generation;state.lastTime=-1;
        if(context.resume>0&&context.resume<duration-3&&time<3){try{video.currentTime=context.resume;return;}catch{state.generation=-1;return;}}
      }
      const now=Date.now(),forced=['pause','seeked','ended','visibility'].includes(reason);
      if(!forced&&(now-state.lastReport<2000||time===state.lastTime))return;
      state.lastReport=now;state.lastTime=time;
      send({kind:'progress',session:context.session,source:state.source,time,duration,paused:video.paused,ended:video.ended,visible,area,reason});
    }
    for(const name of ['loadedmetadata','durationchange','canplay','timeupdate','playing','pause','seeked','ended'])video.addEventListener(name,()=>report(name));
    document.addEventListener('visibilitychange',()=>report('visibility'));
    window.addEventListener('pagehide',()=>report('visibility'));
    state.report=report;report('loadedmetadata');
  }
  function scan(){if(!context)return;for(const video of document.querySelectorAll('video')){observe(video);watched.get(video)?.report();}}
  function tick(){
    if(owner){
      const stage=document.querySelector('#player-stage'),session=stage?.dataset.progressSession||'';
      if(!session){if(lastContext){send({kind:'context',session:'',active:false});context=null;lastContext='';}return;}
      accept({session,resume:Number(stage.dataset.progressResume)||0});
      if(native)window.postMessage({type:'HITMOVIES_AUTO_CAPABILITY',session,available:true,needsAccess:false},location.origin);
      send({kind:'context',session,active:true});lastContext=session;
    }else{forward();scan();}
  }
  new MutationObserver(()=>{forward();scan();}).observe(document,{childList:true,subtree:true});
  setInterval(tick,1000);tick();
})();
