@echo off
start "" "%~dp0HitMovies.exe" --install
