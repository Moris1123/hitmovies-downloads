'use strict';
const autoSessions=new Map(),autoChecks=new Map();
const originOf=value=>{try{const url=new URL(value);return url.protocol==='https:'?url.origin:null;}catch{return null;}};
async function canRead(origin){return !!origin&&chrome.permissions.contains({origins:[origin+'/*']});}
async function inspectChain(tabId){
  if(!await isProtected(tabId))return {error:'Open a movie in HitMovies first.',allowed:[]};
  const frames=await chrome.webNavigation.getAllFrames({tabId});
  const wrapper=frames.find(frame=>frame.parentFrameId===0&&originOf(frame.url)==='https://api.codespecters.com');
  if(!wrapper)return {error:'Open the movie player in HitMovies, then return here.',allowed:[]};
  const allowed=[];let current=wrapper;
  for(let depth=0;depth<5&&current;depth++){
    const origin=originOf(current.url);if(!origin)return {error:'Waiting for the player to load.',allowed};
    if(!await canRead(origin))return {needed:origin,allowed};
    allowed.push(current.frameId);
    let info;
    try{[info]=await chrome.scripting.executeScript({target:{tabId,frameIds:[current.frameId]},func:()=>{
      if(document.querySelector('video'))return {video:true};
      let frame=location.origin==='https://api.codespecters.com'?document.querySelector('#stream-frame'):null;
      if(!frame){const list=[...document.querySelectorAll('iframe')].filter(el=>{const r=el.getBoundingClientRect();return r.width*r.height>Math.max(2000,innerWidth*innerHeight*.4);});list.sort((a,b)=>{const x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return y.width*y.height-x.width*x.height;});frame=list[0];}
      if(!frame)return {waiting:true};
      try{const url=new URL(frame.src);return {origin:url.protocol==='https:'?url.origin:null};}catch{return {waiting:true};}
    }});}catch{return {error:'Reload the movie after allowing player access.',allowed};}
    if(info?.result?.video)return {allowed,ready:true};
    const childOrigin=info?.result?.origin;
    if(!childOrigin)return {allowed,waiting:true};
    if(!await canRead(childOrigin))return {needed:childOrigin,allowed};
    current=frames.find(frame=>frame.parentFrameId===current.frameId&&originOf(frame.url)===childOrigin);
    if(!current)return {allowed,waiting:true};
  }
  return {allowed,waiting:true};
}
async function deliver(tabId,message){try{await chrome.tabs.sendMessage(tabId,message,{frameId:0});}catch{}}
async function checkAutoSave(tabId,force=false){
  const session=autoSessions.get(tabId);if(!session)return;
  if(!force&&Date.now()-(autoChecks.get(tabId)||0)<5000)return;
  autoChecks.set(tabId,Date.now());
  const chain=await inspectChain(tabId);if(autoSessions.get(tabId)!==session)return;
  session.frames=new Set(chain.allowed||[]);
  for(const frameId of chain.allowed||[])try{await chrome.scripting.executeScript({target:{tabId,frameIds:[frameId]},files:['progress-observer.js']});}catch{}
  await deliver(tabId,{type:'hitmovies-capability',session:session.id,available:!chain.error&&!chain.needed,needsAccess:!!chain.needed});
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message?.type==='hitmovies-setup-status'&&sender.id===chrome.runtime.id){inspectChain(message.tabId).then(reply).catch(()=>reply({error:'The player could not be checked.'}));return true;}
  if(message?.type==='hitmovies-setup-refresh'&&sender.id===chrome.runtime.id){checkAutoSave(message.tabId,true).then(()=>reply({ok:true}));return true;}
  if(message?.type!=='hitmovies-observer'||!Number.isInteger(sender.tab?.id))return;
  const tabId=sender.tab.id;
  (async()=>{
    if(!await isProtected(tabId))return;
    if(message.kind==='context'&&sender.frameId===0){
      if(!message.active){autoSessions.delete(tabId);return;}
      if(typeof message.session!=='string'||!/^[-a-z0-9]{20,80}$/i.test(message.session))return;
      if(autoSessions.get(tabId)?.id!==message.session){autoSessions.set(tabId,{id:message.session,frames:new Set()});autoChecks.delete(tabId);}
      await checkAutoSave(tabId);return;
    }
    const session=autoSessions.get(tabId);if(!session||session.id!==message.session)return;
    if(message.kind==='setup'&&sender.frameId===0){await chrome.tabs.create({url:chrome.runtime.getURL('auto-save.html')+'?tab='+tabId});return;}
    if(message.kind==='progress'&&session.frames.has(sender.frameId)){
      const fields=['session','source','time','duration','paused','ended','visible','area','reason'],data={};for(const field of fields)data[field]=message[field];
      await deliver(tabId,{type:'hitmovies-progress-delivery',session:session.id,data});
    }
  })().then(()=>reply({ok:true})).catch(()=>reply({ok:false}));return true;
});
chrome.webNavigation.onCommitted.addListener(details=>{if(details.frameId===0){autoSessions.delete(details.tabId);autoChecks.delete(details.tabId);}else{autoChecks.delete(details.tabId);void checkAutoSave(details.tabId,true);}});
chrome.tabs.onRemoved.addListener(tabId=>{autoSessions.delete(tabId);autoChecks.delete(tabId);});
