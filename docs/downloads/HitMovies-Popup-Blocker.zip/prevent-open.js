(() => {
  'use strict';
  const sites = ['https://hitmovies-emerald-cinema.awaremelon2.chatgpt.site','https://hitmovies-emerald-cinema.matajcicmoris.chatgpt.site'];
  const inHitMovies = sites.includes(location.origin) || Array.from(location.ancestorOrigins || []).some(origin=>sites.includes(origin));
  if (!inHitMovies) return;
  // Stop ordinary HitMovies popups before a new tab is created.
  // The background worker handles popups from cross-origin video-player frames.
  try { Object.defineProperty(window, 'open', {value: () => null, writable: false, configurable: false}); } catch {}
  document.addEventListener('click', event => {
    const anchor = event.composedPath().find(node => node?.tagName === 'A');
    if (!anchor) return;
    const target = (anchor.target || document.querySelector('base[target]')?.target || '').toLowerCase();
    if (target && !['_self', '_parent', '_top'].includes(target)) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
})();
