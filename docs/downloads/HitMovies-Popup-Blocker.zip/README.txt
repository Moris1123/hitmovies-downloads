HitMovies Popup Blocker for Brave

Version 1.0.1. If already installed, reload this extension in Brave to apply the update.

What it does
- Stops normal window.open/new-window links on the HitMovies site.
- Closes new tabs or windows originating from a HitMovies tab, including its embedded player frames.
- Returns focus to the movie after closing an active popup, avoiding a jump to the Extensions page.
- Leaves tabs opened by other websites alone.
- A player popup may briefly flash before Brave reports it and the extension closes it.
- An extension badge counts popup tabs closed in the current session.

Access
- Website access is limited to https://hitmovies-emerald-cinema.awaremelon2.chatgpt.site/.
- Uses Brave's webNavigation events to identify the tab that created a popup.
  Brave may describe this permission as reading browsing history. The code only uses new-tab events, checks whether their source is HitMovies, and does not save browsing history.
- Does not request access to all websites, cookies, passwords, API keys, or browser history storage.
- No remote servers, analytics, persistent activity logs, or network requests.
- New-tab event URLs are not stored or transmitted.

Loading it (requires your approval)
1. Extract the package to a permanent folder.
2. Open brave://extensions/ in Brave.
3. Enable Developer mode, select Load unpacked, and choose this folder (the one containing manifest.json).
4. Reload HitMovies, including any player already open.

Removing it
Open brave://extensions/ and remove HitMovies Popup Blocker.
Keep Brave Shields enabled for advertising content inside the video player.
This extension handles additional tabs, not every ad displayed inside the player.
